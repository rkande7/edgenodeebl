#!/bin/bash

./updater-app
exit $?
